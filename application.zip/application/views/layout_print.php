<script src="<?=base_url()?>assets/js/chartjs/chart.js"></script>
<?php $this->load->view($content)?>


